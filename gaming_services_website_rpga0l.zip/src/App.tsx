import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { About } from "./components/About";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { useEffect } from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <header className="sticky top-0 z-50 bg-black/20 backdrop-blur-md border-b border-purple-500/20">
        <div className="container mx-auto px-4 h-16 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎮</span>
            <h2 className="text-xl font-bold text-white">GameCharge</h2>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-white">
            <a href="#home" className="hover:text-purple-400 transition-colors">الرئيسية</a>
            <a href="#services" className="hover:text-purple-400 transition-colors">الخدمات</a>
            <a href="#about" className="hover:text-purple-400 transition-colors">من نحن</a>
            <a href="#contact" className="hover:text-purple-400 transition-colors">تواصل معنا</a>
          </nav>
          <div className="flex items-center gap-4">
            <Authenticated>
              <SignOutButton />
            </Authenticated>
            <Unauthenticated>
              <button className="text-white hover:text-purple-400 transition-colors">
                تسجيل الدخول
              </button>
            </Unauthenticated>
          </div>
        </div>
      </header>

      <main>
        <Content />
      </main>

      <Footer />
      <Toaster />
    </div>
  );
}

function Content() {
  const seedServices = useMutation(api.seedData.seedServices);
  const services = useQuery(api.services.getServices);

  useEffect(() => {
    // Seed data if no services exist
    if (services && services.length === 0) {
      seedServices();
    }
  }, [services, seedServices]);

  return (
    <>
      <Hero />
      <Services />
      <About />
      <Contact />
    </>
  );
}
