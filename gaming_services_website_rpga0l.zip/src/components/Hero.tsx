export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20"></div>
      <div className="relative z-10 text-center max-w-4xl mx-auto">
        <div className="mb-8">
          <span className="text-6xl mb-4 block">🎮</span>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            مرحبًا بك في وجهتك الأولى
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              لعالم الألعاب!
            </span>
          </h1>
        </div>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
          في موقعنا، نوفر لك كل ما تحتاجه لتكون نجم اللعبة — سواء كنت من عشّاق فري فاير أو محترف في ببجي موبايل
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <div className="text-4xl mb-4">💎</div>
            <h3 className="text-xl font-bold text-white mb-2">شحن جواهر فري فاير</h3>
            <p className="text-gray-300">لحسابك في أقل من دقيقة!</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <div className="text-4xl mb-4">⚡</div>
            <h3 className="text-xl font-bold text-white mb-2">شدات ببجي</h3>
            <p className="text-gray-300">بأسعار منافسة وتوصيل فوري</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <div className="text-4xl mb-4">🛠️</div>
            <h3 className="text-xl font-bold text-white mb-2">بانل فري فاير مميز</h3>
            <p className="text-gray-300">للي حابب يفتح مشروع شحن خاص</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="#services" 
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105 shadow-lg"
          >
            اطلب خدمتك الآن
          </a>
          <a 
            href="#contact" 
            className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white/20 transition-all border border-white/20"
          >
            تواصل معنا
          </a>
        </div>

        <div className="mt-12 flex items-center justify-center gap-8 text-green-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">✅</span>
            <span className="font-semibold">دفع آمن</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🚀</span>
            <span className="font-semibold">دعم فني سريع</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">⚡</span>
            <span className="font-semibold">توصيل فوري</span>
          </div>
        </div>
      </div>
    </section>
  );
}
