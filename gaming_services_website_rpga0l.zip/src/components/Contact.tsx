import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [service, setService] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitContact = useMutation(api.services.submitContact);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !service || !message) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      await submitContact({
        name,
        email: email || undefined,
        phone,
        service,
        message,
      });
      
      toast.success("تم إرسال رسالتك بنجاح! سنتواصل معك قريباً");
      setName("");
      setEmail("");
      setPhone("");
      setService("");
      setMessage("");
    } catch (error) {
      toast.error("حدث خطأ في إرسال الرسالة، يرجى المحاولة مرة أخرى");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            تواصل معنا
          </h2>
          <p className="text-xl text-gray-300">
            نحن هنا لخدمتك على مدار الساعة
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold text-white mb-6">معلومات التواصل</h3>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="bg-purple-600 p-3 rounded-full">
                  <span className="text-white text-xl">📱</span>
                </div>
                <div>
                  <h4 className="text-white font-bold">واتساب</h4>
                  <p className="text-gray-300">+966 XX XXX XXXX</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="bg-purple-600 p-3 rounded-full">
                  <span className="text-white text-xl">📧</span>
                </div>
                <div>
                  <h4 className="text-white font-bold">البريد الإلكتروني</h4>
                  <p className="text-gray-300">support@gamecharge.com</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="bg-purple-600 p-3 rounded-full">
                  <span className="text-white text-xl">⏰</span>
                </div>
                <div>
                  <h4 className="text-white font-bold">ساعات العمل</h4>
                  <p className="text-gray-300">24/7 - على مدار الساعة</p>
                </div>
              </div>
            </div>

            <div className="mt-8 bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
              <h4 className="text-white font-bold mb-4">تابعنا على</h4>
              <div className="flex gap-4">
                <a href="#" className="bg-purple-600 p-3 rounded-full hover:bg-purple-700 transition-colors">
                  <span className="text-white">📘</span>
                </a>
                <a href="#" className="bg-purple-600 p-3 rounded-full hover:bg-purple-700 transition-colors">
                  <span className="text-white">📷</span>
                </a>
                <a href="#" className="bg-purple-600 p-3 rounded-full hover:bg-purple-700 transition-colors">
                  <span className="text-white">🐦</span>
                </a>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/20">
            <h3 className="text-2xl font-bold text-white mb-6">أرسل لنا رسالة</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-white mb-2">الاسم *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  placeholder="أدخل اسمك"
                  required
                />
              </div>

              <div>
                <label className="block text-white mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  placeholder="أدخل بريدك الإلكتروني"
                />
              </div>

              <div>
                <label className="block text-white mb-2">رقم الهاتف *</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  placeholder="أدخل رقم هاتفك"
                  required
                />
              </div>

              <div>
                <label className="block text-white mb-2">نوع الخدمة *</label>
                <select
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  required
                >
                  <option value="">اختر نوع الخدمة</option>
                  <option value="freefire">شحن جواهر فري فاير</option>
                  <option value="pubg">شحن شدات ببجي</option>
                  <option value="panel">بانل الشحن</option>
                  <option value="other">أخرى</option>
                </select>
              </div>

              <div>
                <label className="block text-white mb-2">الرسالة *</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none h-32 resize-none"
                  placeholder="اكتب رسالتك هنا..."
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-50"
              >
                {isSubmitting ? "جاري الإرسال..." : "إرسال الرسالة"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
