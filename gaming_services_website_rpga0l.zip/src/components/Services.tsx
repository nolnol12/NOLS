import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ServiceCard } from "./ServiceCard";

export function Services() {
  const freefireServices = useQuery(api.services.getServices, { type: "freefire" });
  const pubgServices = useQuery(api.services.getServices, { type: "pubg" });
  const panelServices = useQuery(api.services.getServices, { type: "panel" });

  return (
    <section id="services" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            خدماتنا المميزة
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            اختر الخدمة المناسبة لك واستمتع بتجربة لعب لا تُنسى
          </p>
        </div>

        {/* Free Fire Services */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <span className="text-4xl">💎</span>
            <h3 className="text-3xl font-bold text-white">شحن جواهر فري فاير</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {freefireServices?.map((service) => (
              <ServiceCard key={service._id} service={service} />
            ))}
          </div>
        </div>

        {/* PUBG Services */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <span className="text-4xl">⚡</span>
            <h3 className="text-3xl font-bold text-white">شحن شدات ببجي موبايل</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pubgServices?.map((service) => (
              <ServiceCard key={service._id} service={service} />
            ))}
          </div>
        </div>

        {/* Panel Services */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <span className="text-4xl">🛠️</span>
            <h3 className="text-3xl font-bold text-white">بانل الشحن الاحترافي</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {panelServices?.map((service) => (
              <ServiceCard key={service._id} service={service} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
