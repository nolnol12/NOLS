export function About() {
  return (
    <section id="about" className="py-20 px-4 bg-black/20">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            لماذا تختارنا؟
          </h2>
          <p className="text-xl text-gray-300">
            نحن نقدم أفضل خدمات الشحن في المنطقة
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/20">
            <div className="text-4xl mb-4">🚀</div>
            <h3 className="text-2xl font-bold text-white mb-4">سرعة في التوصيل</h3>
            <p className="text-gray-300 leading-relaxed">
              نضمن لك وصول الشحنة في أقل من دقيقة واحدة. فريقنا يعمل على مدار الساعة لضمان أسرع خدمة ممكنة.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/20">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-2xl font-bold text-white mb-4">أمان مضمون</h3>
            <p className="text-gray-300 leading-relaxed">
              جميع المعاملات محمية بأحدث تقنيات الأمان. بياناتك وحسابك في أمان تام معنا.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/20">
            <div className="text-4xl mb-4">💰</div>
            <h3 className="text-2xl font-bold text-white mb-4">أسعار منافسة</h3>
            <p className="text-gray-300 leading-relaxed">
              نقدم أفضل الأسعار في السوق مع عروض وخصومات مستمرة لعملائنا المميزين.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/20">
            <div className="text-4xl mb-4">🎧</div>
            <h3 className="text-2xl font-bold text-white mb-4">دعم فني 24/7</h3>
            <p className="text-gray-300 leading-relaxed">
              فريق الدعم الفني متاح على مدار الساعة لحل أي مشكلة أو الإجابة على استفساراتك.
            </p>
          </div>
        </div>

        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl p-8 border border-purple-500/20">
            <h3 className="text-2xl font-bold text-white mb-4">إحصائياتنا</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">10K+</div>
                <div className="text-gray-300">عميل سعيد</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">50K+</div>
                <div className="text-gray-300">عملية شحن</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">99%</div>
                <div className="text-gray-300">معدل النجاح</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">24/7</div>
                <div className="text-gray-300">دعم فني</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
