import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface Service {
  _id: string;
  type: string;
  name: string;
  description: string;
  price: number;
  amount: number;
  icon?: string;
}

interface ServiceCardProps {
  service: Service;
}

export function ServiceCard({ service }: ServiceCardProps) {
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [gameId, setGameId] = useState("");
  const [playerName, setPlayerName] = useState("");
  const [contactInfo, setContactInfo] = useState("");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createOrder = useMutation(api.services.createOrder);

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!gameId || !contactInfo) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      await createOrder({
        service: service.type,
        package: service.name,
        gameId,
        playerName: playerName || undefined,
        amount: service.amount,
        price: service.price,
        contactInfo,
        notes: notes || undefined,
      });
      
      toast.success("تم إرسال طلبك بنجاح! سنتواصل معك قريباً");
      setShowOrderForm(false);
      setGameId("");
      setPlayerName("");
      setContactInfo("");
      setNotes("");
    } catch (error) {
      toast.error("حدث خطأ في إرسال الطلب، يرجى المحاولة مرة أخرى");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20 hover:border-purple-400/40 transition-all hover:transform hover:scale-105">
        <div className="text-center mb-4">
          <div className="text-3xl mb-2">{service.icon}</div>
          <h4 className="text-xl font-bold text-white mb-2">{service.name}</h4>
          <p className="text-gray-300 text-sm mb-4">{service.description}</p>
        </div>
        
        <div className="text-center mb-6">
          <div className="text-3xl font-bold text-purple-400 mb-1">
            ${service.price}
          </div>
          <div className="text-gray-300 text-sm">
            {service.type === "panel" ? "مرة واحدة" : `${service.amount} ${service.type === "freefire" ? "جوهرة" : "UC"}`}
          </div>
        </div>

        <button
          onClick={() => setShowOrderForm(true)}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold hover:from-purple-700 hover:to-pink-700 transition-all"
        >
          اطلب الآن
        </button>
      </div>

      {showOrderForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-xl p-6 w-full max-w-md border border-purple-500/20">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white">طلب {service.name}</h3>
              <button
                onClick={() => setShowOrderForm(false)}
                className="text-gray-400 hover:text-white text-2xl"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleOrder} className="space-y-4">
              <div>
                <label className="block text-white mb-2">
                  {service.type === "panel" ? "اسم المستخدم المطلوب" : "معرف اللعبة"} *
                </label>
                <input
                  type="text"
                  value={gameId}
                  onChange={(e) => setGameId(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  placeholder={service.type === "panel" ? "أدخل اسم المستخدم" : "أدخل معرف اللعبة"}
                  required
                />
              </div>

              {service.type !== "panel" && (
                <div>
                  <label className="block text-white mb-2">اسم اللاعب (اختياري)</label>
                  <input
                    type="text"
                    value={playerName}
                    onChange={(e) => setPlayerName(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                    placeholder="أدخل اسم اللاعب"
                  />
                </div>
              )}

              <div>
                <label className="block text-white mb-2">رقم الواتساب *</label>
                <input
                  type="text"
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none"
                  placeholder="أدخل رقم الواتساب"
                  required
                />
              </div>

              <div>
                <label className="block text-white mb-2">ملاحظات إضافية</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:border-purple-500 focus:outline-none h-20 resize-none"
                  placeholder="أي ملاحظات إضافية..."
                />
              </div>

              <div className="bg-slate-700 rounded-lg p-4 mb-4">
                <div className="flex justify-between text-white">
                  <span>المجموع:</span>
                  <span className="font-bold text-purple-400">${service.price}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowOrderForm(false)}
                  className="flex-1 bg-slate-600 text-white py-3 rounded-lg font-bold hover:bg-slate-700 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-50"
                >
                  {isSubmitting ? "جاري الإرسال..." : "تأكيد الطلب"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
