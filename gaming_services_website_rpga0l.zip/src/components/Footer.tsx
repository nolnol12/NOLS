export function Footer() {
  return (
    <footer className="bg-black/40 backdrop-blur-sm border-t border-purple-500/20 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🎮</span>
              <h3 className="text-xl font-bold text-white">GameCharge</h3>
            </div>
            <p className="text-gray-300 leading-relaxed">
              وجهتك الأولى لشحن الألعاب بأفضل الأسعار وأسرع خدمة في المنطقة.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">خدماتنا</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-purple-400 transition-colors">شحن فري فاير</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">شحن ببجي موبايل</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">بانل الشحن</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">دعم فني</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">روابط مهمة</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-purple-400 transition-colors">الشروط والأحكام</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">سياسة الخصوصية</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">الأسئلة الشائعة</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">تتبع الطلب</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">تواصل معنا</h4>
            <div className="space-y-2 text-gray-300">
              <p>📱 واتساب: +966 XX XXX XXXX</p>
              <p>📧 support@gamecharge.com</p>
              <p>⏰ متاح 24/7</p>
            </div>
          </div>
        </div>

        <div className="border-t border-purple-500/20 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            © 2024 GameCharge. جميع الحقوق محفوظة.
          </p>
          <p className="text-gray-400 text-sm mt-2">
            جربنا وخلّي لعبك يكون غير! 🎮
          </p>
        </div>
      </div>
    </footer>
  );
}
