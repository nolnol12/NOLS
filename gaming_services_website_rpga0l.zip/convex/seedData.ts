import { mutation } from "./_generated/server";

export const seedServices = mutation({
  args: {},
  handler: async (ctx) => {
    // Free Fire packages
    const freefireServices = [
      { type: "freefire", name: "100 جوهرة", description: "شحن سريع وآمن", price: 5, amount: 100, isActive: true, icon: "💎" },
      { type: "freefire", name: "310 جوهرة", description: "الأكثر شعبية", price: 15, amount: 310, isActive: true, icon: "💎" },
      { type: "freefire", name: "520 جوهرة", description: "قيمة ممتازة", price: 25, amount: 520, isActive: true, icon: "💎" },
      { type: "freefire", name: "1080 جوهرة", description: "للاعبين المحترفين", price: 50, amount: 1080, isActive: true, icon: "💎" },
      { type: "freefire", name: "2180 جوهرة", description: "العرض الأفضل", price: 100, amount: 2180, isActive: true, icon: "💎" },
    ];

    // PUBG packages
    const pubgServices = [
      { type: "pubg", name: "60 UC", description: "شحن سريع وآمن", price: 3, amount: 60, isActive: true, icon: "⚡" },
      { type: "pubg", name: "325 UC", description: "الأكثر شعبية", price: 15, amount: 325, isActive: true, icon: "⚡" },
      { type: "pubg", name: "660 UC", description: "قيمة ممتازة", price: 30, amount: 660, isActive: true, icon: "⚡" },
      { type: "pubg", name: "1800 UC", description: "للاعبين المحترفين", price: 80, amount: 1800, isActive: true, icon: "⚡" },
      { type: "pubg", name: "3850 UC", description: "العرض الأفضل", price: 160, amount: 3850, isActive: true, icon: "⚡" },
    ];

    // Panel services
    const panelServices = [
      { type: "panel", name: "بانل مبتدئ", description: "للمبتدئين في مجال الشحن", price: 200, amount: 1, isActive: true, icon: "🛠️" },
      { type: "panel", name: "بانل احترافي", description: "للمحترفين مع مميزات إضافية", price: 500, amount: 1, isActive: true, icon: "🛠️" },
      { type: "panel", name: "بانل متقدم", description: "أفضل الخيارات مع دعم كامل", price: 1000, amount: 1, isActive: true, icon: "🛠️" },
    ];

    // Insert all services
    for (const service of [...freefireServices, ...pubgServices, ...panelServices]) {
      await ctx.db.insert("services", service);
    }

    return "Services seeded successfully!";
  },
});
