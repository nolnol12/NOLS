import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  orders: defineTable({
    userId: v.optional(v.id("users")),
    service: v.string(), // "freefire", "pubg", "panel"
    package: v.string(),
    gameId: v.string(),
    playerName: v.optional(v.string()),
    amount: v.number(),
    price: v.number(),
    status: v.string(), // "pending", "processing", "completed", "failed"
    paymentMethod: v.optional(v.string()),
    contactInfo: v.string(),
    notes: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_status", ["status"]),

  services: defineTable({
    type: v.string(), // "freefire", "pubg", "panel"
    name: v.string(),
    description: v.string(),
    price: v.number(),
    amount: v.number(),
    isActive: v.boolean(),
    icon: v.optional(v.string()),
  }).index("by_type", ["type"])
    .index("by_active", ["isActive"]),

  contacts: defineTable({
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.string(),
    service: v.string(),
    message: v.string(),
    status: v.string(), // "new", "contacted", "resolved"
  }).index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
